******************************************************************************************
Changes from original model and some mappings and textures by: T.O.M.
******************************************************************************************
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SOME CHANGES TO MODEL AND NEW MAPPINGS BY IISQ. I ALSO MODIFIED NEW LOWPOLY FROM NADEO ORIGINAL
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


*********************************************
*              StadiumCar TMU               *
* 	   All Environments compatible	    *
*********************************************

Original Author : NADEO

Converted all environments by wrc


Instal :
Put the zip file in ...\My documents\TrackMania United\Skins\Vehicles\CarCommon

!!WITHOUT UNZIPPING IT !!
